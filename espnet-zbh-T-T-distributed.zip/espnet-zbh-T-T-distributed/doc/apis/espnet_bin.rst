.. _core tools:

core tools
==========

ESPnet provides several command-line tools for training and evaluating neural networks (NN) under ``espnet/bin``:

.. include:: ../_gen/espnet_bin.rst
