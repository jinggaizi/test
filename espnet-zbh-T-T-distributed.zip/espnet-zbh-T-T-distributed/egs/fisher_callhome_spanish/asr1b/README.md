This recipe is prepared for the ASR component in the pipelined speech translation system.
The only difference from 'asr1' is that audio segmentation.
This 'asr1b' recipe is besed on https://github.com/joshua-decoder/fisher-callhome-corpus.git.
